package Grupo2.grupo2;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * JavaFX App
 */
public class App extends Application {

	private static Scene scene;

	@Override
	public void start(Stage stage) throws IOException {
		 //Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
		// scene = new Scene(root);
		Parent root = FXMLLoader.load(getClass().getResource("eleccion.fxml"));
		scene = new Scene(root);
//		stage.initStyle(StageStyle.UNDECORATED);
		stage.setTitle("Discografica");
		stage.getIcons().add(new Image(getClass().getResourceAsStream("/imgs/discografica.png")));
		stage.setScene(scene);
		stage.setResizable(false);
		stage.show();
	}

	public static void main(String[] args) {
		launch();
	}

}