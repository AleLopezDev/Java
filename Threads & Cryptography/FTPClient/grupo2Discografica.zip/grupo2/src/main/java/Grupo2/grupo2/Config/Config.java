package Grupo2.grupo2.Config;

public class Config {
	
	// MySQL
	public static final String HOST_BBDD = "localhost";
	public static final String DRIVER_BBDD = "com.mysql.cj.jdbc.Driver";
	public static final String IP_BBDD = "jdbc:mysql://localhost/";
	public static final String ARCHIVO_BBDD = "discografica";
	public static final String USUARIO_BBDD = "root";
	public static final String PSSW_BBDD = "";
	
	// FTP
	public static final String IP_FTP = "192.168.1.15";
	public static final String USER_FTP = "discoUser";
	public static final String PASSWORD_FTP = "pepe";
	
}
