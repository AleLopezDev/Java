package Grupo2.grupo2;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.scene.control.TreeItem;

// Clase para que a la hora de crear una carpeta vacia te la detecte como carpeta
public class CrearCarpeta extends TreeItem<String> {

	public CrearCarpeta(String text, FontAwesomeIconView iconoCarpeta) {
		super(text, iconoCarpeta);
	}

}
