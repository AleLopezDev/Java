package Grupo2.grupo2;

// Esta clase sirve para obtener los datos del usuario que se logea.
public class DatosUsuario {
	private static String idUsuario; 
	static String nombreUsuario; 
	static String contrasenia; 
	static String admin;
	
	public static String getIdUsuario() {
		return idUsuario;
	}
	public static void setIdUsuario(String idUsuario) {
		DatosUsuario.idUsuario = idUsuario;
	}
	public static String getNombreUsuario() {
		return nombreUsuario;
	}
	public static void setNombreUsuario(String nombreUsuario) {
		DatosUsuario.nombreUsuario = nombreUsuario;
	}
	public static String getContrasenia() {
		return contrasenia;
	}
	public static void setContrasenia(String contrasenia) {
		DatosUsuario.contrasenia = contrasenia;
	}
	public static String getAdmin() {
		return admin;
	}
	public static void setAdmin(String admin) {
		DatosUsuario.admin = admin;
	} 
}
