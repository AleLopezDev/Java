package Grupo2.grupo2.controladores;

import java.io.IOException;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

import Grupo2.grupo2.DatosUsuario;
import Grupo2.grupo2.Config.Config;
import Grupo2.grupo2.paqueteConexion.Conexion;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.scene.control.TreeItem;

public class ClienteFTP {

	private FTPClient cliente;
	private String nombreUsuario;
	static String mensaje = "";
	Conexion conexion = new Conexion();

	// variable de control de las acciones del log (funciona como un booleano)
	int control = 0;
	int filas = 0;

	public void crearConexion() {

		cliente = new FTPClient();
		cliente.setAutodetectUTF8(true);

		try {
			if (!cliente.isConnected()) {
				cliente.connect(Config.IP_FTP);
				boolean haLogeado = cliente.login(Config.USER_FTP, Config.PASSWORD_FTP);
				if (haLogeado) {

					// Para pasar el firewall
					cliente.enterLocalPassiveMode();

					this.nombreUsuario = ControladorLoginFTP.nombreUsuario;

					if (!nombreUsuario.equals("admin")) {
						// Crea una carpeta inicial con el nombre del usuario
						crearCarpetaInicio(ControladorLoginFTP.nombreUsuario);
					}

					// Cambiar al directorio del usuario
					cliente.changeWorkingDirectory("/" + ControladorLoginFTP.nombreUsuario);

					mensaje = "MSG: Cliente" + ControladorLoginFTP.nombreUsuario + " logeado " + haLogeado;

					System.out.println(mensaje);

					control = 1;
				} else {
					control = 0;

				}
			}
			// metodo para insertar logs
			mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(), "login", mensaje,
					control);
		} catch (IOException e) {
			// Manejar la excepción
			e.printStackTrace();
		}
	}

	public void recogerArchivos(FTPClient cliente, FTPFile file, TreeItem<String> currentNode) throws IOException {

		FTPFile[] files = cliente.listFiles();
		for (FTPFile i : files) {

			if (i.isDirectory()) {
				// Crea un nodo con un icono de carpeta
				FontAwesomeIconView folderIcon = new FontAwesomeIconView(FontAwesomeIcon.FOLDER);
				folderIcon.setStyle("-fx-font-size: 16px;-fx-font-family:FontAwesome;");

				TreeItem<String> folderNode = new TreeItem<String>(i.getName(), folderIcon);
				currentNode.getChildren().add(folderNode);
				currentNode.setExpanded(true);

				cliente.changeWorkingDirectory(i.getName());
				recogerArchivos(cliente, i, folderNode);
				cliente.changeToParentDirectory();
			} else {
				// Crea un nodo con un icono de archivo
				FontAwesomeIconView fileIcon = new FontAwesomeIconView(FontAwesomeIcon.FILE_TEXT_ALT);
				fileIcon.setStyle("-fx-font-family:FontAwesome;-fx-fill: #00a0ff;-fx-font-size: 14px;");

				TreeItem<String> fileNode = new TreeItem<String>(i.getName(), fileIcon);
				currentNode.getChildren().add(fileNode);
			}
		}
	}

	public void mensajeLog(int idUser, String nombreUsuario, String operacion, String mensaje, int resultado) {
		conexion.crearConexion(Config.IP_BBDD, Config.ARCHIVO_BBDD, Config.USUARIO_BBDD, Config.PSSW_BBDD,
				Config.DRIVER_BBDD);
		String sql = "INSERT INTO log (id_usuario, nombre_usuario, operacion, descripcion, resultado) values " + "('"
				+ idUser + "', '" + nombreUsuario + "', '" + operacion + "', '" + mensaje + "', '" + resultado + "')";
		conexion.crearStatement();
		filas = conexion.crearActualizaciones(sql);
	}

	public void crearCarpetaInicio(String nombreUsuario) throws IOException {
		cliente.makeDirectory(nombreUsuario);
	}

	public FTPClient getCliente() {
		return this.cliente;
	}

	public String getNombreUsuario() {
		return this.nombreUsuario;
	}

}
