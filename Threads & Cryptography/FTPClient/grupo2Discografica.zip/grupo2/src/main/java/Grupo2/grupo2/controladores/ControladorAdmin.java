package Grupo2.grupo2.controladores;

import java.net.URL;
import java.security.MessageDigest;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import Grupo2.grupo2.DatosUsuario;
import Grupo2.grupo2.Usuario;
import Grupo2.grupo2.Config.Config;
import Grupo2.grupo2.paqueteConexion.Conexion;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class ControladorAdmin implements Initializable {
	Conexion con = crearConexionBD();
	ClienteFTP cliente = new ClienteFTP();
	String mensaje = "";
	int control = 0;
	int filas = 0;
	@FXML
	private Label info;
	@FXML
	private Button aniadirBT, modificarBT, eliminarBT, nuevoBT, salirBT;
	@FXML
	private TextField idTF, usuarioTF, passwordTF;
	@FXML
	private CheckBox adminCB;
	@FXML
	private TableView<Usuario> tablaUsuario;
	@FXML
	private TableColumn idCL, usuarioCL, passwordCL, adminCL;

	ObservableList<Usuario> usuarios;

	private int posicionUsuarioEnTabla;

	@FXML
	private void salida(ActionEvent event) {
		Stage stage = (Stage) salirBT.getScene().getWindow();
		stage.close();
	}

//	@FXML
//	private void administrar(ActionEvent event) {
//		String nombreUsuario = usuarioTF.getText();
//		String contrasenna = passwordTF.getText();
//
//		Stage stage = new Stage();
//		FXMLLoader loader = new FXMLLoader();
//
//		if (!existenciaUsuario(nombreUsuario, contrasenna)) {
//			return;
//		}
//
//		loader.setLocation(getClass().getResource("/Grupo2/grupo2/MenuUsuario.fxml"));
//
//		try {
//			Pane ventana = (Pane) loader.load();
//			Scene scene = new Scene(ventana);
//			stage.setScene(scene);
//			stage.setResizable(false);
//			stage.show();
//
//			// cierro esta ventana
//			stage = (Stage) joinBT.getScene().getWindow();
//			stage.close();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}

	private boolean existenciaUsuario(String nombreUsuario, String contrasenna) {
		Conexion con = crearConexionBD();

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT id, password");
		sql.append(" FROM usuarios");
		sql.append(" WHERE usuario LIKE '");
		sql.append(nombreUsuario);
		sql.append("';");

		con.crearConsulta(sql.toString());

		try {
			if (con.getRs().next()) {
				if (!con.getRs().getString(2).equals(contrasenna)) {
					return false;
				}
				recuperarDatosUsuario();
				con.cerrarResult();
				cerrarConexiones(con);

				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		con.cerrarResult();
		cerrarConexiones(con);

		return false;
	}

	private void cerrarConexiones(Conexion con) {
		con.cerrarStatement();
		con.cerrarConexion();
	}

	private void recuperarDatosUsuario() throws SQLException {
		Conexion con = new Conexion();
		con.crearConexion(Config.IP_BBDD, Config.ARCHIVO_BBDD, Config.USUARIO_BBDD, Config.PSSW_BBDD,
				Config.DRIVER_BBDD);
		con.crearStatement();

		String nombreUsuario = usuarioTF.getText();
		String sql = "SELECT * FROM usuarios where usuario = '" + nombreUsuario + "'";

		con.crearConsulta(sql);
		DatosUsuario datosUsuario = new DatosUsuario();
		if (con.getRs().next()) {
			datosUsuario.setIdUsuario(String.valueOf(con.getRs().getInt(1)));
			datosUsuario.setNombreUsuario(con.getRs().getString(2));
			datosUsuario.setContrasenia(con.getRs().getString(3));
			datosUsuario.setAdmin(String.valueOf(con.getRs().getInt(4)));
		}
	}

	@FXML
	private void nuevo(ActionEvent event) {
		info.setTextFill(Color.DARKORANGE);
		info.setText("En proceso de añadir...");

		String valor = "1";

		String sqlInsert = "SELECT MAX(id) FROM usuarios";

		con.crearConsulta(sqlInsert);

		try {
			if (con.getRs().next()) {
				valor = con.getRs().getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		int idNuevo = Integer.parseInt(valor) + 1;
		idTF.setText("" + idNuevo);
		usuarioTF.setText("");
		passwordTF.setText("");
		adminCB.setSelected(false);
		modificarBT.setDisable(true);
		eliminarBT.setDisable(true);
		aniadirBT.setDisable(false);
	}

	@FXML
	private void modificar(ActionEvent event) throws Exception {
		boolean check = false;

		Usuario usu = new Usuario();
		usu.setId(Integer.parseInt(idTF.getText()));
		usu.setUsuario(usuarioTF.getText());
		usu.setPassword(passwordTF.getText());
		if (adminCB.isSelected()) {
			usu.setAdmin(1);
		} else {
			usu.setAdmin(0);
		}
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT *");
		sql.append(" FROM usuarios");
		sql.append(";");

		con.crearConsulta(sql.toString());

		try {
			if (con.getRs().next()) {
				if (usu.getUsuario().equals(con.getRs().getString(2))) {
					check = true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		String passwordEncriptada = encryptPassword(passwordTF.getText());

		if (check) {
			info.setTextFill(Color.RED);
			info.setText("Modificado con exito. No cambio el nombre");
			String sqlInsert = "";
			if (adminCB.isSelected()) {
				sqlInsert = "UPDATE usuarios SET id=" + Integer.parseInt(idTF.getText()) + ", password='"
						+ passwordEncriptada + "', admin='" + 1 + "' WHERE " + posicionUsuarioEnTabla;
				System.out.println(sqlInsert);
			} else {
				sqlInsert = "UPDATE usuarios SET id=" + Integer.parseInt(idTF.getText()) + ", password='"
						+ passwordEncriptada + "', admin='" + 0 + "' WHERE " + posicionUsuarioEnTabla;
				System.out.println(sqlInsert);
			}
			con.crearActualizaciones(sqlInsert);

			usuarios.set(posicionUsuarioEnTabla, usu);
		} else {
			info.setTextFill(Color.BLUEVIOLET);
			info.setText("Usuario modificado con exito");

			String sqlInsert = "";
			if (adminCB.isSelected()) {
				sqlInsert = "UPDATE usuarios SET id=" + Integer.parseInt(idTF.getText()) + ", usuario='"
						+ usuarioTF.getText() + "', password='" + passwordEncriptada + "', admin='" + 1 + "' WHERE id="
						+ Integer.parseInt(idTF.getText());
			} else {
				sqlInsert = "UPDATE usuarios SET id=" + Integer.parseInt(idTF.getText()) + ", usuario='"
						+ usuarioTF.getText() + "', password='" + passwordEncriptada + "', admin='" + 0 + "' WHERE id="
						+ Integer.parseInt(idTF.getText());
			}
			filas = con.crearActualizaciones(sqlInsert);

			if (filas > 0) {
				mensaje = "Usuario " + usuarioTF.getText() + " modificado correctamente";
				control = 1;
			} else {
				mensaje = "Usuario " + usuarioTF.getText() + " no se ha podido modificar";
				control = 0;
			}

			cliente.mensajeLog(Integer.parseInt(idTF.getText()), usuarioTF.getText(), "Modificar", mensaje, control);

			usuarios.set(posicionUsuarioEnTabla, usu);
		}
	}

	@FXML
	private void aniadir(ActionEvent event) throws Exception {
		modificarBT.setDisable(true);
		eliminarBT.setDisable(true);
		if (usuarioTF.getText().equals("") || passwordTF.getText().equals("")) {
			info.setTextFill(Color.RED);
			info.setText("Rellena todos los campos");
		} else {
			aniadirBT.setDisable(true);

			boolean check = false;

			Usuario usu = new Usuario();
			usu.setId(Integer.parseInt(idTF.getText()));
			usu.setUsuario(usuarioTF.getText());

			usu.setPassword(passwordTF.getText());
			if (adminCB.isSelected()) {
				usu.setAdmin(1);
			} else {
				usu.setAdmin(0);
			}

			StringBuilder sql = new StringBuilder();
			sql.append("SELECT *");
			sql.append(" FROM usuarios");
			sql.append(";");

			con.crearConsulta(sql.toString());

			try {
				while (con.getRs().next()) {
					System.out.println(usu.getUsuario() + " ?= " + con.getRs().getString(2));
					if (usu.getUsuario().equals(con.getRs().getString(2))) {
						check = true;
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if (check) {
				info.setTextFill(Color.RED);
				info.setText("Este nombre de usuario ya existe");
			} else {
				info.setTextFill(Color.BLUEVIOLET);
				info.setText("Usuario añadido con exito");
				usuarios.add(usu);
				String sqlInsert = "";

				// Encriptamos la contraseña

				String passwordEncriptada = encryptPassword(passwordTF.getText());

				// Si es admin
				if (adminCB.isSelected()) {
					sqlInsert = "INSERT INTO usuarios (id, usuario, password, admin) VALUES ("
							+ Integer.parseInt(idTF.getText()) + ", '" + usuarioTF.getText() + "', '"
							+ passwordEncriptada + "', " + 1 + ")";
				} else {
					sqlInsert = "INSERT INTO usuarios (id, usuario, password, admin) VALUES ("
							+ Integer.parseInt(idTF.getText()) + ", '" + usuarioTF.getText() + "', '"
							+ passwordEncriptada + "', " + 0 + ")";
				}

				filas = con.crearActualizaciones(sqlInsert);

				if (filas > 0) {
					mensaje = "Usuario " + usuarioTF.getText() + " añadido correctamente";
					control = 1;
				} else {
					mensaje = "Usuario " + usuarioTF.getText() + " no se ha podido añadir";
					control = 0;
				}

				cliente.mensajeLog(Integer.parseInt(idTF.getText()), usuarioTF.getText(), "Añadir", mensaje, control);
			}
			idTF.setText("");
		}
	}

	@FXML
	private void eliminar(ActionEvent event) {
		String sqlInsert = "DELETE FROM usuarios WHERE id=" + idTF.getText();
		filas = con.crearActualizaciones(sqlInsert);

		if (filas > 0) {
			mensaje = "Usuario " + usuarioTF.getText() + " eliminado correctamente";
			control = 1;
		} else {
			mensaje = "Usuario " + usuarioTF.getText() + " no se ha podido eliminar";
			control = 0;
		}
		cliente.mensajeLog(Integer.parseInt(idTF.getText()), usuarioTF.getText(), "Eliminar", mensaje, control);

		usuarios.remove(posicionUsuarioEnTabla);
	}

	private final ListChangeListener<Usuario> selectorTablaPersonas = new ListChangeListener<Usuario>() {
		@Override
		public void onChanged(ListChangeListener.Change<? extends Usuario> c) {
			ponerPersonaSeleccionada();
		}
	};

	public Usuario getTablaPersonasSeleccionada() {
		info.setTextFill(Color.DARKORANGE);
		try {
			info.setText(
					"Seleccionado el usuario con id: " + tablaUsuario.getSelectionModel().getSelectedItem().getId());
		} catch (Exception e) {
		}
		if (tablaUsuario != null) {
			List<Usuario> tabla = tablaUsuario.getSelectionModel().getSelectedItems();
			if (tabla.size() == 1) {
				final Usuario competicionSeleccionada = tabla.get(0);
				return competicionSeleccionada;
			}
		}
		return null;
	}

	private void ponerPersonaSeleccionada() {
		final Usuario usu = getTablaPersonasSeleccionada();
		posicionUsuarioEnTabla = usuarios.indexOf(usu);

		if (usu != null) {

			idTF.setText("" + usu.getId());
			usuarioTF.setText(usu.getUsuario());
			passwordTF.setText(usu.getPassword());
			if (adminCB.isSelected()) {
				usu.setAdmin(1);
			} else {
				usu.setAdmin(0);
			}
			modificarBT.setDisable(false);
			eliminarBT.setDisable(false);
			aniadirBT.setDisable(true);

		}
	}

	private void inicializarTablaPersonas() {
		idCL.setCellValueFactory(new PropertyValueFactory<Usuario, String>("id"));
		usuarioCL.setCellValueFactory(new PropertyValueFactory<Usuario, String>("usuario"));
		passwordCL.setCellValueFactory(new PropertyValueFactory<Usuario, Integer>("password"));
		adminCL.setCellValueFactory(new PropertyValueFactory<Usuario, String>("admin"));

		usuarios = FXCollections.observableArrayList();
		tablaUsuario.setItems(usuarios);
	}

	public static String encryptPassword(String password) throws Exception {
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(password.getBytes());

		byte[] digest = md.digest();
		StringBuilder sb = new StringBuilder();
		for (byte b : digest) {
			sb.append(String.format("%02x", b));
		}

		return sb.toString();
	}

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		idTF.setDisable(true);

		this.inicializarTablaPersonas();

		modificarBT.setDisable(true);
		eliminarBT.setDisable(true);
		aniadirBT.setDisable(true);

		final ObservableList<Usuario> tablaSel = tablaUsuario.getSelectionModel().getSelectedItems();
		tablaSel.addListener(selectorTablaPersonas);

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT *");
		sql.append(" FROM usuarios");
		sql.append(";");

		con.crearConsulta(sql.toString());

		try {
			while (con.getRs().next()) {
				Usuario relleno = new Usuario();
				relleno.setId(con.getRs().getInt(1));
				relleno.setUsuario(con.getRs().getString(2));
				relleno.setPassword(con.getRs().getString(3));
				relleno.setAdmin(con.getRs().getInt(4));
				usuarios.add(relleno);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private Conexion crearConexionBD() {
		Conexion con = new Conexion();

		try {
			con.crearConexion(Config.IP_BBDD, Config.ARCHIVO_BBDD, Config.USUARIO_BBDD, Config.PSSW_BBDD,
					Config.DRIVER_BBDD);
			con.crearStatement();

			return con;
		} catch (Exception e) {
			System.err.println("No se pude conectar con la base de datos.");
			e.printStackTrace();
		}
		return null;
	}
}