package Grupo2.grupo2.controladores;

import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.URI;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorInicio {

	@FXML
	private Button btnSalir, btnFTP, btnAPK, btnMAIL;

	private Stage stage;

	FXMLLoader loader = new FXMLLoader();

	public void salir() {
		Stage stage = (Stage) this.btnSalir.getScene().getWindow();
		stage.close();
	}

	public void minimizar() {

	}

	@FXML
	public void cambiarFTP() throws IOException {
		cambiarVentana(btnFTP, "/Grupo2/grupo2/Login.fxml");
	}

	public void mail() throws IOException {
		cambiarVentana(btnMAIL, "/Grupo2/grupo2/LoginMail.fxml");
	}

	public void android() {
		loader.setLocation(getClass().getResource("/Grupo2/grupo2/VistaSecundaria.fxml"));
	}

	public void web() {
		try {
			Desktop.getDesktop().browse(new URI("https://discografica2grupo.000webhostapp.com/"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void cambiarVentana(Button btn, String localizacion) throws IOException {
		// Obtén una referencia al Stage actual
		Stage stage = (Stage) btn.getScene().getWindow();

		FXMLLoader loader = new FXMLLoader(getClass().getResource(localizacion));
		Parent root = loader.load();

		stage.setScene(new Scene(root));
	}
}
