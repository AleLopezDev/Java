package Grupo2.grupo2.controladores;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import Grupo2.grupo2.DatosUsuario;
import Grupo2.grupo2.Config.Config;
import Grupo2.grupo2.paqueteConexion.Conexion;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class ControladorLoginFTP implements Initializable {

	@FXML
	private TextField cajaCorreo;
	@FXML
	private TextField cajaContrasenna;
	@FXML
	private Button botonInicioSesion, btnSalir;

	static String nombreUsuario;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// poner el focus por defecto a la caja del correo
		Platform.runLater(() -> cajaCorreo.requestFocus());
	}

	public void cerrar() {
		Stage stage = (Stage) this.btnSalir.getScene().getWindow();
		stage.close();
	}

	@FXML
	public void limpiarCajaCorreo(KeyEvent event) {
		limpiarError(cajaCorreo);

		if (event.getCode() == KeyCode.ENTER) {
			cajaContrasenna.requestFocus();
		}
	}

	@FXML
	public void limpiarCajaContrasenna(KeyEvent event) {
		limpiarError(cajaContrasenna);

		if (event.getCode() == KeyCode.ENTER) {
			try {
				conectar();
			} catch (Exception e) {
				mostrarError("No ha sido posible la conexión con la base de datos.");
			}
		}
	}

	@FXML
	public void iniciarSesion(ActionEvent event) {
		try {
			conectar();
		} catch (Exception e) {
			mostrarError("No ha sido posible la conexión con la base de datos.");
		}
	}

	private void conectar() throws Exception {
		nombreUsuario = cajaCorreo.getText();
		String password = cajaContrasenna.getText();
		String passDesencriptada = ControladorAdmin.encryptPassword(password);

		System.out.println(passDesencriptada);

		Stage stage = new Stage();
		FXMLLoader loader = new FXMLLoader();

//		if (!existenciaUsuario(nombreUsuario, passDesencriptada)) {
		if (!existenciaUsuario(nombreUsuario, password)) {
			return;
		}

		if (!comprobarAdmin(nombreUsuario)) {
			// abrir la ventana del admin
			loader.setLocation(getClass().getResource("/Grupo2/grupo2/VistaSecundaria.fxml"));
		} else {
			// abrir ventanas del cliente
			loader.setLocation(getClass().getResource("/Grupo2/grupo2/MenuUsuario.fxml"));
		}

		try {
			Pane ventana = (Pane) loader.load();
			Scene scene = new Scene(ventana);
			stage.setTitle("Discográfica - FTP");
			stage.getIcons().add(new Image(getClass().getResourceAsStream("/imgs/fptFX.png")));
			stage.setScene(scene);
			stage.setResizable(false);
			stage.show();

			// cierro esta ventana
			stage = (Stage) this.botonInicioSesion.getScene().getWindow();
			stage.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void limpiarError(TextField caja) {
		caja.setStyle("-fx-border-color: transparent");
	}

	private boolean existenciaUsuario(String nombre, String contrasenna) {
		Conexion con = crearConexionBD();

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT id, password");
		sql.append(" FROM usuarios");
		sql.append(" WHERE usuario LIKE '");
		sql.append(nombre);
		sql.append("';");

		con.crearConsulta(sql.toString());

		try {
			if (con.getRs().next()) {
				if (!con.getRs().getString(2).equals(contrasenna)) {
					// contraseña incorrecta
					cajaContrasenna.setStyle("-fx-border-color: red");
					mostrarError("Contraseña incorrecta.");

					return false;
				}
				recuperarDatosUsuario();
				con.cerrarResult();
				cerrarConexiones(con);

				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		cajaCorreo.setStyle("-fx-border-color: red");
		mostrarError("Usuario incorrecto.");

		con.cerrarResult();
		cerrarConexiones(con);

		return false;
	}

	private void mostrarError(String mensaje) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setHeaderText(null);
		alert.setTitle("Error");
		alert.setContentText(mensaje);
		alert.showAndWait();
	}

	private boolean comprobarAdmin(String nombreUsusario) {
		Conexion con = crearConexionBD();

		StringBuilder sql = new StringBuilder();
		sql.append("SELECT admin");
		sql.append(" FROM usuarios");
		sql.append(" WHERE usuario LIKE '");
		sql.append(nombreUsusario);
		sql.append("';");

		con.crearConsulta(sql.toString());

		try {
			if (con.getRs().next()) {
				if (con.getRs().getInt(1) == 0) {
					con.cerrarResult();
					cerrarConexiones(con);

					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		con.cerrarResult();
		cerrarConexiones(con);

		return false;
	}

	private Conexion crearConexionBD() {
		Conexion con = new Conexion();

		try {
			con.crearConexion(Config.IP_BBDD, Config.ARCHIVO_BBDD, Config.USUARIO_BBDD, Config.PSSW_BBDD,
					Config.DRIVER_BBDD);
			con.crearStatement();

			return con;
		} catch (Exception e) {
			System.err.println("No se pude conectar con la base de datos.");
			e.printStackTrace();
		}

		return null;
	}

	private void cerrarConexiones(Conexion con) {
		con.cerrarStatement();
		con.cerrarConexion();
	}

	public void recuperarDatosUsuario() throws SQLException {
		Conexion con = new Conexion();
		con.crearConexion(Config.IP_BBDD, Config.ARCHIVO_BBDD, Config.USUARIO_BBDD, Config.PSSW_BBDD,
				Config.DRIVER_BBDD);
		con.crearStatement();

		String nombreUsuario = cajaCorreo.getText();
		String sql = "SELECT * FROM usuarios where usuario = '" + nombreUsuario + "'";

		con.crearConsulta(sql);
		DatosUsuario datosUsuario = new DatosUsuario();
		if (con.getRs().next()) {
			datosUsuario.setIdUsuario(String.valueOf(con.getRs().getInt(1)));
			datosUsuario.setNombreUsuario(con.getRs().getString(2));
			datosUsuario.setContrasenia(con.getRs().getString(3));
			datosUsuario.setAdmin(String.valueOf(con.getRs().getInt(4)));
		}
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

}
