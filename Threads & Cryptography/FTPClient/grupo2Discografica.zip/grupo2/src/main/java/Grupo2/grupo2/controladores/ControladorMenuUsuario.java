package Grupo2.grupo2.controladores;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Optional;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.ftpserver.usermanager.Md5PasswordEncryptor;

import Grupo2.grupo2.CrearCarpeta;
import Grupo2.grupo2.DatosUsuario;
import Grupo2.grupo2.Config.Config;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ControladorMenuUsuario {

	@FXML
	private TreeView<String> treeArchivos;
	@FXML
	private Button btnSalir, btnOk, btnAnular;
	@FXML
	private Label labelIP, labelUsuario, labelHost, labelRol, labelPort;

	private FTPClient cliente;
	private String nombreUsuario;
	static ClienteFTP c;
	private TreeItem<String> rootNode;

	ClienteFTP clienteLog = new ClienteFTP();
	String mensaje = "";
	int control = 0;

	@FXML
	public void initialize() throws IOException {

		c = new ClienteFTP();
		c.crearConexion();

		this.cliente = c.getCliente();
		this.nombreUsuario = c.getNombreUsuario();

		// Seteamos los texts a los label
		labelIP.setText("IP: " + c.getCliente().getLocalAddress());
		labelUsuario.setText("Usuario: " + ControladorLoginFTP.nombreUsuario);
		labelHost.setText("Host: " + Config.IP_FTP);
		labelPort.setText(String.valueOf(c.getCliente().getDefaultPort()));

		if (ControladorLoginFTP.nombreUsuario.equals("admin")) {
			labelRol.setText("Rol: Admin");
		} else {
			labelRol.setText("Rol: Usuario");
		}

		// Crea un nodo raíz y lo establece como el nodo raíz del treeView
		rootNode = new TreeItem<String>(ControladorLoginFTP.nombreUsuario);
		rootNode.setExpanded(true);
		treeArchivos.setRoot(rootNode);

		// Recoge los archivos y los inserta en el treeview
		c.recogerArchivos(c.getCliente(), null, rootNode);
	}

	@FXML
	public String obtenerRuta() throws IOException {
		StringBuilder pathBuilder = new StringBuilder();
		for (TreeItem<String> item = this.treeArchivos.getSelectionModel().getSelectedItem(); item != null; item = item
				.getParent()) {
			pathBuilder.insert(0, item.getValue());
			pathBuilder.insert(0, "/");
		}
		return pathBuilder.toString();
	}

	public String obtenerRuta(TreeItem<String> itemOrigen) throws IOException {
		StringBuilder pathBuilder = new StringBuilder();
		for (TreeItem<String> item = itemOrigen; item != null; item = item.getParent()) {
			pathBuilder.insert(0, item.getValue());
			pathBuilder.insert(0, "/");
		}

		return pathBuilder.toString();
	}

	@FXML
	public String obtenerRutaPadre() throws IOException {
		StringBuilder pathBuilder = new StringBuilder();
		for (TreeItem<String> item = this.treeArchivos.getSelectionModel().getSelectedItem(); item != null; item = item
				.getParent()) {
			pathBuilder.insert(0, item.getValue());
			pathBuilder.insert(0, "/");
		}
		// Dividir la ruta completa en dos partes: ruta del directorio padre y nombre
		// del archivo
		int lastSlashIndex = pathBuilder.lastIndexOf("/");
		String dirPath = pathBuilder.substring(0, lastSlashIndex);
		return dirPath;
	}

	private String obtenerRutaPadre(TreeItem<String> itemOrigen) {
		StringBuilder pathBuilder = new StringBuilder();
		for (TreeItem<String> item = itemOrigen; item != null; item = item.getParent()) {
			pathBuilder.insert(0, item.getValue());
			pathBuilder.insert(0, "/");
		}
		// Dividir la ruta completa en dos partes: ruta del directorio padre y nombre
		// del archivo
		int lastSlashIndex = pathBuilder.lastIndexOf("/");
		String dirPath = pathBuilder.substring(0, lastSlashIndex);
		return dirPath;
	}

	@FXML
	public void salirMenuSesion() throws IOException {
		Stage stage = (Stage) this.btnSalir.getScene().getWindow();
		mostrarOpcion("/Grupo2/grupo2/Login.fxml", false);
		stage.close();
		mensaje = "El usuario " + nombreUsuario + " se ha desconectado";
		clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(), "Logout",
				mensaje, 1);
		cliente.disconnect();
	}

	public void mostrarOpcion(String ruta, boolean alert) throws IOException {
		FXMLLoader loader = new FXMLLoader();
		if (alert) {
			Pane pane = (Pane) loader.load(getClass().getResource(ruta).openStream());

			Scene scene = new Scene(pane);
			Stage stage = new Stage();
			stage.setResizable(false);
			stage.setScene(scene);
			stage.initModality(Modality.APPLICATION_MODAL);

			stage.showAndWait();
		} else {
			loader.setLocation(getClass().getResource(ruta));
			Pane ventana = (Pane) loader.load();
			Scene scene = new Scene(ventana);
			Stage stage = new Stage();
			stage.setScene(scene);
			stage.setResizable(false);
			stage.show();

			stage = (Stage) this.btnSalir.getScene().getWindow();
			stage.close();
		}

	}

	@FXML
	public void descargarArchivo() throws IOException {
		TreeItem<String> itemSeleccionado = treeArchivos.getSelectionModel().getSelectedItem();

		// Si no hay ningún elemento seleccionado
		if (itemSeleccionado == null) {
			mostrarError("No se ha seleccionado ningún elemento");
			return;
		}

		// Si es una carpeta
		if (detectarCarpeta(itemSeleccionado.getValue())) {
			mostrarError("No se pueden descargar carpetas.");
			return;
		}

		String nombreArchivo = obtenerRuta();
		String[] partes = nombreArchivo.split("/");
		String nombreCompleto = partes[partes.length - 1];

		// Usuario elija la ruta de destino
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Elija la ruta de destino para el archivo descargado");

//		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("ALL files", "*.*"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("TXT files (.txt)", "*.txt"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF files (.pdf)", "*.pdf"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("IMG files (.img)", "*.img"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("MP3 files (.mp3)", "*.mp3"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("MP4 files (.mp4)", "*.mp4"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("JPG files (.jpg)", "*.jpg"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("JPEG files (.jpeg)", "*.jpeg"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG files (.png)", "*.png"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("ZIP files (.zip)", "*.zip"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("WINRAR files (.rar)", "*.rar"));

		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
		fileChooser.setInitialFileName(nombreCompleto);

		if (!fileChooser.getInitialFileName().contains(".") && !detectarCarpeta(itemSeleccionado.getValue())) {
			if (nombreCompleto.split(".").length < 2) {
				fileChooser.setInitialFileName(fileChooser.getInitialFileName() + ".txt");
			} else {
				fileChooser.setInitialFileName(fileChooser.getInitialFileName() + nombreCompleto.split(".")[1]);
			}
		}

		File archivoDestino = fileChooser.showSaveDialog(null);

		if (archivoDestino == null) {
			// Si no elige ningun lugar de descarga cierra
			return;
		}


		// CONTROLAR QUE NO TENGA LA EXTENSION
		String[] nombre = archivoDestino.getPath().split("/");
		String nombeExts = nombre[nombre.length - 1];
		
		// CONTROLAR QUE NO TENGA LA EXTENSEION
//		String[] nombre = archivoDestino.getPath().split("/");
//		String nombeExts = nombre[nombre.length - 1];
//
//		if (nombeExts.split(".").length == 2) {
//			String extens = "." + nombreExt.split(".")[1];
//			archivoDestino.renameTo(new File(archivoDestino.getPath(), archivoDestino + extens));
//		}


		// es un fichero
		if (!detectarCarpeta(itemSeleccionado.getValue())) {

			OutputStream os = new BufferedOutputStream(new FileOutputStream(archivoDestino));

			boolean descargado = cliente.retrieveFile(nombreArchivo, os);

			os.close();

			if (descargado) {
				control = 1;

				mensaje = "Se ha descargado el archivo " + nombreArchivo + " correctamente";

				clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
						"Descarga", mensaje, control);

				clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
						"Descarga", mensaje, control);
				mostrarAviso("El archivo se descargó correctamente.");

			} else {
				control = 0;
				mensaje = "No se ha podido descargar el archivo " + nombreArchivo;
				clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
						"Descarga", mensaje, control);
				mostrarError("No se ha podido descargar el archivo.");
			}

			return;
		}
	}

	// Al ser una funcion fxml no se pueden usar parametros
	@FXML
	public void borrarArchivo() throws IOException {

		boolean eliminado = false;

		TreeItem<String> itemSeleccionado = treeArchivos.getSelectionModel().getSelectedItem();

		// Verificar si se ha seleccionado un elemento
		if (itemSeleccionado == null) {
			mostrarError("No se ha seleccionado ningún elemento");
			return;
		} else if (itemSeleccionado.getParent() == null) {
			mostrarError("No se puede borrar la carpeta raiz");
			return;
		}

		String nombreArchivo = itemSeleccionado.getValue();
		boolean esCarpeta = detectarCarpeta(nombreArchivo);

		if (esCarpeta == true) {
			// Si es una carpeta vacia
			if (itemSeleccionado.getChildren().size() == 0) {
				if (!mostrarConfirmacion("¿Seguro que desea eliminar la carpeta?")) {
					return;
				}

				eliminado = cliente.removeDirectory(obtenerRuta());
			} else {
//				if (!mostrarConfirmacion("Se eliminará todo el contenido. \n ¿Desea continuar?")) {
//					return;
//				}
//				
				// No elimina de forma recursiva
//				eliminado = borrarRecursivo(eliminado, itemSeleccionado, obtenerRuta());
				mostrarError("Para eliminar una carpeta con contenido debe ser vaciada primero.");
				return;
			}
		} else {
			if (!mostrarConfirmacion("¿Seguro que desea eliminar el archivo?")) {
				return;
			}

			eliminado = cliente.deleteFile(obtenerRuta());
		}

		if (eliminado) {
			TreeItem<String> padre = itemSeleccionado.getParent();
			padre.getChildren().remove(itemSeleccionado);
			treeArchivos.refresh();
			control = 1;
			mensaje = "El archivo " + nombreArchivo + " se ha borrado correctamente";
			clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
					"Borrado", mensaje, control);
			mostrarAviso("El archivo se eliminó correctamente.");
		} else {
			control = 0;
			mensaje = "El archivo " + nombreArchivo + " no se ha podido borrar";
			clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
					"Borrado", mensaje, control);

			mostrarError("No se ha podido borrar la carpeta correctamente");
		}

	}

	// NO USADO
	private boolean borrarRecursivo(boolean eliminado, TreeItem<String> itemSeleccionado, String ruta)
			throws IOException {
		System.out.println(itemSeleccionado.getValue() + " <-- El valor del item");

		// si es carpeta
		if (detectarCarpeta(ruta, itemSeleccionado)) {
			System.out.println("El item " + itemSeleccionado.getValue() + " es una carpeta.");
			ObservableList<TreeItem<String>> hijos = itemSeleccionado.getChildren();

			// si esta vacia
			if (hijos.size() == 0) {
				System.out.println("El item " + itemSeleccionado + " está vacio.");
				eliminado = cliente.removeDirectory(new File(obtenerRuta(itemSeleccionado)).getPath());
//				eliminado = cliente.deleteFile(new File(obtenerRuta(itemSeleccionado)).getPath()); // no borra
				return eliminado;
			}

			System.out.println("El item " + itemSeleccionado.getValue() + " tiene " + hijos.size() + " hijos.");
			// si tiene contenido
			for (TreeItem<String> hijo : hijos) {
				cliente.changeWorkingDirectory(new File(obtenerRuta(itemSeleccionado)).getPath());
				eliminado = borrarRecursivo(eliminado, hijo, ruta + "/" + hijo.getValue());
				return eliminado;
			}
		}

		System.out.println("El item " + itemSeleccionado.getValue() + " es un fichero.");

		// si es fichero
		eliminado = cliente.deleteFile(new File(itemSeleccionado.getValue()).getPath());
		return eliminado;
	}

	@FXML
	public void renombrarArchivoFTP() throws IOException {
		// Obtener el elemento seleccionado en el TreeView
		TreeItem<String> itemSeleccionado = treeArchivos.getSelectionModel().getSelectedItem();

		// Si no hay ningún elemento seleccionado
		if (itemSeleccionado == null) {
			mostrarError("No se ha seleccionado ningún elemento");
			return;
		}

		String nombreArchivoActual = itemSeleccionado.getValue();

		// Pedir al usuario que ingrese el nuevo nombre para el archivo o directorio
		TextInputDialog dialog = new TextInputDialog();
		dialog.setTitle("Renombrar archivo");
		dialog.setHeaderText("Ingrese el nuevo nombre para el archivo o directorio seleccionado:");
		dialog.setContentText("Nuevo nombre:");

		Optional<String> result = dialog.showAndWait();

		if (!result.isPresent() || result.get() == "") {
			mostrarError("Escribe un nombre");
			return;
		}

		String nombreArchivoNuevo = result.get();

		// Obtener la ruta del directorio padre del archivo seleccionado
		String dirPath = obtenerRutaPadre();

		// Renombrar el archivo
		boolean renombrado = cliente.rename(obtenerRuta(), dirPath + "/" + nombreArchivoNuevo); // Arrela

		// Si no se pudo renombrar, mostrar un mensaje de error
		if (!renombrado) {
			control = 0;
			mensaje = "El archivo " + nombreArchivoActual + " no se ha podido renombrar a " + nombreArchivoNuevo;

			clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
					"Renombrar", mensaje, control);

			clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
					"Renombrar", mensaje, control);
			mostrarError("No se pudo renombrar el archivo");
			return;
		}

		mostrarAviso("El archivo se renombró correctamente.");

		// Si se pudo renombrar, actualizar el nombre en el TreeView
		itemSeleccionado.setValue(nombreArchivoNuevo);

		treeArchivos.refresh();
		control = 1;
		mensaje = "El archivo " + nombreArchivoActual + " se ha renombrado correctamente con el nombre "
				+ nombreArchivoNuevo;
		clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
				"Renombrar", mensaje, control);

		control = 1;
		mensaje = "El archivo " + nombreArchivoActual + " se ha renombrado correctamente con el nombre "
				+ nombreArchivoNuevo;
		clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
				"Renombrar", mensaje, control);
	}

	@FXML
	public void crearCarpeta(ActionEvent event) throws IOException {
		boolean creado = false;
		TreeItem<String> itemSeleccionado = treeArchivos.getSelectionModel().getSelectedItem();

		// Creamos el icono de folder
		FontAwesomeIconView iconoCarpeta = new FontAwesomeIconView(FontAwesomeIcon.FOLDER);
		iconoCarpeta.setStyle("-fx-font-size: 14px;-fx-font-family:FontAwesome;");

		// Pedir al usuario que ingrese el nuevo nombre para el directorio
		TextInputDialog dialog = new TextInputDialog();
		dialog.setTitle("Crear Carpeta");
		dialog.setHeaderText("Ingrese el nombre para la nueva carpeta:");
		dialog.setContentText("Nombre:");

		Optional<String> result = dialog.showAndWait();

		if (!result.isPresent() || result.get() == "") {
			mostrarError("Escribe un nombre");
			return;
		}
		String nombreCarpeta = result.get().trim();

		if (itemSeleccionado == null) {
			creado = cliente.makeDirectory("/" + ControladorLoginFTP.nombreUsuario + "/" + nombreCarpeta);
			if (creado) {
				TreeItem<String> itemCarpeta = new TreeItem<String>(nombreCarpeta, iconoCarpeta);
				actualizarTreeView(itemCarpeta);
				mensaje = "Se ha creado correctamente la carpeta " + nombreCarpeta;
				control = 1;
				clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
						"Crear carpeta", mensaje, control);
				mostrarCorrecto("Carpeta creada en la raiz");
			} else {
				mostrarError("No se pudo crear la carpeta, compruebe que no hay otras con el mismo nombre");
			}
			return;
		}
		// Metodo para detectar si el archivo pinchado es una carpeta o no
		boolean esCarpeta = detectarCarpeta(itemSeleccionado.getValue());

		if (esCarpeta == true) {

			String ruta = obtenerRuta();
			if (ruta == "") {
				ruta = ControladorLoginFTP.nombreUsuario;
			}

			creado = cliente.makeDirectory("/" + ruta + "/" + nombreCarpeta);
		} else {

			String ruta = obtenerRutaPadre();
			if (ruta == "") {
				ruta = ControladorLoginFTP.nombreUsuario;
			}
			creado = cliente.makeDirectory("/" + ruta + "/" + nombreCarpeta);
		}

		if (creado) {

			CrearCarpeta carpetaNueva = new CrearCarpeta(nombreCarpeta, iconoCarpeta);

			actualizarTreeView(carpetaNueva);

			mensaje = "Se ha creado correctamente la carpeta " + nombreCarpeta;
			control = 1;
			clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
					"Crear carpeta", mensaje, control);
			mostrarCorrecto("Carpeta creada correctamente.");
		} else {
			mensaje = "No se ha podido crear la carpeta " + nombreCarpeta;
			control = 0;
			clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
					"Crear carpeta", mensaje, control);
			mostrarError("Error creando la carpeta");
		}

	}

	@FXML
	public void nuevoArchivo() throws IOException {
		boolean creado = false;
		TreeItem<String> itemSeleccionado = treeArchivos.getSelectionModel().getSelectedItem();
		// Creamos el icono de folder
		FontAwesomeIconView iconoArchivo = new FontAwesomeIconView(FontAwesomeIcon.FILE_TEXT_ALT);
		iconoArchivo.setStyle("-fx-font-family:FontAwesome;-fx-fill: #00a0ff;-fx-font-size: 12px;");

		// Pedir al usuario que ingrese el nuevo nombre para el directorio
		TextInputDialog dialog = new TextInputDialog();
		dialog.setTitle("Crear Carpeta");

		dialog.setHeaderText("Ingrese el nombre para la nueva carpeta:");
		dialog.setContentText("Nombre:");

		Optional<String> result = dialog.showAndWait();

		if (!result.isPresent() || result.get() == "") {
			mostrarError("Escribe un nombre");
			return;
		}
		String nombreArchivo = result.get().trim();
		String[] partes = nombreArchivo.split("/");
		String nombreCompleto = partes[partes.length - 1];
		
		// Control de extension
		if (nombreCompleto.split(".").length < 2) {
			nombreArchivo += ".txt";
		}
		
		// Si no se selecciona ningun item del treeview, se añade a la ruta del servidor
		if (itemSeleccionado == null) {
			creado = cliente.storeFile("/" + ControladorLoginFTP.nombreUsuario + "/" + nombreArchivo,
					new ByteArrayInputStream(new byte[0]));
			if (creado) {
				TreeItem<String> archivoNuevo = new TreeItem<>(nombreArchivo, iconoArchivo);
				actualizarTreeView(archivoNuevo);
				mostrarCorrecto("Archivo creado correctamente");
			}
			return;
		}

		boolean esCarpeta = detectarCarpeta(itemSeleccionado.getValue());

		if (esCarpeta == true) {

			String ruta = obtenerRuta();
			if (ruta == "") {
				ruta = ControladorLoginFTP.nombreUsuario;
			}

			creado = cliente.storeFile("/" + ruta + "/" + nombreArchivo, new ByteArrayInputStream(new byte[0]));
		} else {
			String ruta = obtenerRutaPadre();

			if (ruta == "") {
				ruta = ControladorLoginFTP.nombreUsuario;
			}

			creado = cliente.storeFile("/" + ruta + "/" + nombreArchivo, new ByteArrayInputStream(new byte[0]));
		}

		if (creado) {
			TreeItem<String> archivoNuevo = new TreeItem<>(nombreArchivo, iconoArchivo);

			// Actualiza el treeView
			actualizarTreeView(archivoNuevo);

			mensaje = "Se ha creado correctamente el archivo " + nombreArchivo;
			control = 1;
			clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
					"Crear archivo", mensaje, control);
			mostrarCorrecto("Archivo creado correctamente.");
		} else {
			mensaje = "No se ha podido crear el archivo " + nombreArchivo;
			control = 0;
			clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
					"Crear archivo", mensaje, control);
			mostrarError("Error creando el archivo");
		}
	}

	@FXML
	public void subirArchivo() throws IOException {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Seleccionar archivo");

		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("ALL files", "*.*"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("TXT files (.txt)", "*.txt"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF files (.pdf)", "*.pdf"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("IMG files (.img)", "*.img"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("MP3 files (.mp3)", "*.mp3"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("MP4 files (.mp4)", "*.mp4"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("JPG files (.jpg)", "*.jpg"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("JPEG files (.jpeg)", "*.jpeg"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG files (.png)", "*.png"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("ZIP files (.zip)", "*.zip"));
		fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("WINRAR files (.rar)", "*.rar"));

		File archivo = fileChooser.showOpenDialog(null);

		// Si el usuario ha seleccionado un archivo, procede a subirlo
		if (archivo != null && archivo.isFile()) {
			FileInputStream fis = new FileInputStream(archivo.getAbsolutePath());

			boolean subido = cliente.storeFile(obtenerRuta() + "/" + archivo.getName(), fis);

			if (subido) {
				FontAwesomeIconView iconoArchivo = new FontAwesomeIconView(FontAwesomeIcon.FILE_TEXT_ALT);
				iconoArchivo.setStyle("-fx-font-family:FontAwesome;-fx-fill: #00a0ff;-fx-font-size: 12px;");
				TreeItem<String> archivoNuevo = new TreeItem<>(archivo.getName(), iconoArchivo);

				// Actualiza el treeView
				actualizarTreeView(archivoNuevo);
				mensaje = "Se ha subido corretamente el archivo " + archivoNuevo.getValue();
				control = 1;
				clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
						"Subir archivo", mensaje, control);
				mostrarCorrecto("Se ha subido correctamente el archivo");
			} else {
				mensaje = "No se ha podido subir el archivo: " + archivo.getName();
				control = 0;
				clienteLog.mensajeLog(Integer.parseInt(DatosUsuario.getIdUsuario()), DatosUsuario.getNombreUsuario(),
						"Subir archivo", mensaje, control);
				mostrarError("No se ha subido el archivo");
			}

			fis.close();
		}
	}

	private boolean detectarCarpeta(String nombreArchivo) throws IOException {
		cliente.changeWorkingDirectory(obtenerRuta());

		FTPFile[] listaFTP = cliente.listFiles(obtenerRutaPadre());

		for (FTPFile i : listaFTP) {
			if (i.getName().equals(nombreArchivo)) {
				if (i.isDirectory()) {
					return true;
				}
			}
		}

		return false;
	}

	private boolean detectarCarpeta(String ruta, TreeItem<String> item) throws IOException {
		String nombreArchivo = item.getValue();
		cliente.changeWorkingDirectory(ruta);

		FTPFile[] listaFTP = cliente.listFiles(obtenerRutaPadre(item));

		for (FTPFile i : listaFTP) {
			if (i.getName().equals(nombreArchivo)) {
				if (i.isDirectory()) {
					return true;
				}
			}
		}

		return false;
	}

	private boolean mostrarConfirmacion(String mensaje) {
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setHeaderText(null);
		alert.setTitle("Aviso");
		alert.setContentText(mensaje);
		alert.showAndWait();

		if (!alert.getResult().getButtonData().equals(ButtonData.OK_DONE)) {
			return false;
		}

		return true;
	}

	private void mostrarCorrecto(String mensaje) {
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setHeaderText(null);
		alert.setTitle("Correcto");
		alert.setContentText(mensaje);
		alert.showAndWait();
	}

	private void mostrarAviso(String mensaje) {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("Aviso");
		alert.setContentText(mensaje);
		alert.showAndWait();
	}

	private void mostrarError(String mensaje) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setHeaderText(null);
		alert.setTitle("Error");
		alert.setContentText(mensaje);
		alert.showAndWait();

	}

	private void actualizarTreeView(TreeItem<String> itemNuevo) throws IOException {

		// Obtén el TreeItem seleccionado actualmente en el TreeView
		TreeItem<String> itemSeleccionado = treeArchivos.getSelectionModel().getSelectedItem();
		// Si no selecciona ningun archivo lo añade a la carpeta raiz
		if (itemSeleccionado == null) {
			treeArchivos.getRoot().getChildren().add(itemNuevo);
			return;
		}

		boolean esCarpeta = detectarCarpeta(itemSeleccionado.getValue());

		// Si es una carpeta
		if (esCarpeta == true) {
			itemSeleccionado.getChildren().add(itemNuevo);
			itemSeleccionado.setExpanded(true);
		} else {
			TreeItem<String> padre = itemSeleccionado.getParent();

			if (padre != null) {
				padre.getChildren().add(itemNuevo);
			}
			// Si el padre es nulo, lo esta creando en la carpeta raiz
			else {
				treeArchivos.getRoot().getChildren().add(itemNuevo);
			}
		}

		treeArchivos.refresh();
	}

	public FTPClient getCliente() {
		return cliente;
	}

	public String getNombreUsuario() {
		return this.nombreUsuario;
	}

	public TreeView<String> getTreeArchivos() {
		return treeArchivos;
	}

}