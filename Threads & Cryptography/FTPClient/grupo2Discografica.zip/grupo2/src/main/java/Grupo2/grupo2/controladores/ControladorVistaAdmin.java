package Grupo2.grupo2.controladores;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ControladorVistaAdmin {
	@FXML
	private Button gestionUser;
	@FXML
	private Label labelServer;
	@FXML
	private Button btnDesconectar;

	@FXML
	public void clickButton(ActionEvent event) {

		if (event.getSource().equals(gestionUser)) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/Grupo2/grupo2/VistaMenuAdmin.fxml"));
			try {
				Parent root = loader.load();
				/*
				 * Agregar controlador de VistaMenuAdmin en esta línea
				 */
				Scene scene = new Scene(root);
				Stage stage = new Stage();

				stage.initModality(Modality.APPLICATION_MODAL);
				stage.setScene(scene);
				stage.showAndWait();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (event.getSource().equals(btnDesconectar)) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/Grupo2/grupo2/Login.fxml"));
			Parent root;
			try {
				root = loader.load();
				Scene scene = new Scene(root);
				Stage stage = new Stage();
				stage.initModality(Modality.APPLICATION_MODAL);
				stage.setScene(scene);
				stage.show();
				
				// cierro esta ventana
				stage = (Stage) this.btnDesconectar.getScene().getWindow();
				stage.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
