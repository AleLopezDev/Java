package Grupo2.grupo2.paqueteConexion;

import java.sql.*;

public class Conexion {
	private Statement state;
	private ResultSet rs;
	private ResultSetMetaData rsmd;
	private Connection con;

	// Driver personal -> com.mysql.cj.jdbc.Driver
	// Driver para profe -> com.mysql.jdbc.Driver
	// Ip -> jdbc:mysql://localhost/
	// usuario -> root
	// contrasenna -> "" (porque no tengo contrase�a)

	/**
	 * Carga el driver y accede a la base de datos. Ejemplos: <br>
	 * IP -> jdbc:mysql://localhost/ <br>
	 * Archivo -> nombre de la base de datos. <br>
	 * Usuario -> root <br>
	 * Passw -> "" <br>
	 * Driver -> com.mysql.cj.jdbc.Driver
	 * 
	 * @param ip
	 * @param archivo
	 * @param usuario
	 * @param passw
	 * @param driver
	 */
	public void crearConexion(String ip, String archivo, String usuario, String passw, String driver) {
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(ip + archivo, usuario, passw);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Ejecuta sentencias SQL de consulta.
	 * 
	 * @param sql sentencia que ejecutar�.
	 */
	public void crearConsulta(String sql) {
		try {
			rs = state.executeQuery(sql); // SELECT
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Ejecuta sentencias SQL de UPDATE, INSERT, DROP, CREATE y ALTER.
	 * 
	 * @param sql sentencia SQL que se ejecutar�.
	 * @return Devuelve el n�mero de registros afectados.
	 */
	public int crearActualizaciones(String sql) {
		try {
			return state.executeUpdate(sql); // UPDATE, INSERT, DROP, CREATE y ALTER
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	/**
	 * Necesa
	 */
	public void crearStatement() {
		try {
			this.state = this.con.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Tabla virtual de datos con los datos de la propia tabla como el nombre o el
	 * n�mero de campos.
	 */
	public void crearMetaDataRs() {
		try {
			rsmd = rs.getMetaData();
		} catch (SQLException e) {
			e.getStackTrace();
		}
	}

	// CERRAR ENLACES

	public void cerrarResult() {
		try {
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void cerrarStatement() {
		try {
			state.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void cerrarConexion() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// GETTERS & SETTERS

	public Statement getState() {
		return state;
	}

	public void setState(Statement state) {
		this.state = state;
	}

	public ResultSet getRs() {
		return rs;
	}

	public void setRs(ResultSet rs) {
		this.rs = rs;
	}

	public ResultSetMetaData getRsmd() {
		return rsmd;
	}

	public void setRsmd(ResultSetMetaData rsmd) {
		this.rsmd = rsmd;
	}
}
