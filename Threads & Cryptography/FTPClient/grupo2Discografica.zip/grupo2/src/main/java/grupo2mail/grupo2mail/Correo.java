package grupo2mail.grupo2mail;

import javafx.scene.image.ImageView;

public class Correo {
	private String destinatario;
	private String asunto;
	private String fecha;

	public Correo(String destinatario, String asunto, String fecha) {
		super();
		this.destinatario = destinatario;
		this.asunto = asunto;
		this.fecha = fecha;
	}

	public String getDestinatario() {
		return destinatario;
	}

	public void setDestinatario(String destinatario) {
		this.destinatario = destinatario;
	}

	public String getAsunto() {
		return asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

}
