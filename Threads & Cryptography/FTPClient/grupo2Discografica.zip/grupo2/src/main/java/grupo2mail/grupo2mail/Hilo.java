package grupo2mail.grupo2mail;

import javax.mail.MessagingException;

/**
 * 
 * @author Javier Jim�nez Torres
 *
 */
public class Hilo extends Thread {
	
	private RecibirCorreos miTuberia;
	
	/**
	 * Contructor
	 * @param miTuberia tuberia dode est� el m�todo donde va a recibir y contruir la tabla
	 */
	public Hilo(RecibirCorreos miTuberia) {
		this.setName("hilo1");
		this.miTuberia = miTuberia;

	}
	@SuppressWarnings("static-access")
	@Override
	public void run() {
		try {
			while(true) { // un while true donde va a refrescar cada minuto el correo y contruir de nuevo la tabla
				miTuberia.recibirCorreos();
				System.out.println("Comienzo hilo");
				miTuberia.construirVentana();
				System.out.println("Final hilo");
				sleep(120000);
			}
			
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
