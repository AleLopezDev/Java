package grupo2mail.grupo2mail;

import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;
import java.util.ResourceBundle;

import grupo2mail.grupo2mail.conexion.ConexionBD;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import modelo.ModeloConsultas;

public class LoginMailController implements Initializable {
	@FXML
	private Button inicioBT;

	@FXML
	private TextField correoTF;
	@FXML
	private PasswordField contrasennaTF;

	private String correo;
	private String contrasenna;
	private RecibirCorreos rc;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		Platform.runLater(() -> correoTF.requestFocus());
	}

	@FXML
	public void iniciarSesion(ActionEvent event) throws IOException {
		System.out.println("He pulsao");
		conectar();
	}

	private void conectar() throws IOException {
		correo = correoTF.getText();
		contrasenna = contrasennaTF.getText();

		System.out.println("He pulsado el boton");

		ConexionBD con = new ConexionBD();
		con.crearConexion();

		ModeloConsultas consultas = new ModeloConsultas();

		System.out.println(consultas.getExisteUsuario(correoTF.getText().toString(), contrasennaTF.getText().toString()));

		if (con.existeUsusuario(consultas.getExisteUsuario(correoTF.getText().toString(), contrasennaTF.getText().toString()))) {
			System.out.println(correoTF.getText() + " | " + contrasennaTF.getText());
			RecibirCorreos rc = new RecibirCorreos(correoTF.getText().toString(), contrasennaTF.getText().toString());
			
			this.rc=rc;
			
			Stage stage = new Stage();
			FXMLLoader loader = new FXMLLoader();
			
			loader.setLocation(getClass().getResource("/grupo2/grupo2/VistaTablaMail.fxml"));
			
			Pane ventana = (Pane) loader.load();
			Scene scene = new Scene(ventana);
			stage.setScene(scene);
			stage.show();
			
			TablaMailController controller = (TablaMailController) loader.getController();
			controller.recibirParametros(rc, correo, contrasenna);

			Hilo hilo = new Hilo(rc);
			hilo.start();
		}
	}

	public String getCorreo() {
		return correo;
	}

	public String getContrasenna() {
		return contrasenna;
	}
}
