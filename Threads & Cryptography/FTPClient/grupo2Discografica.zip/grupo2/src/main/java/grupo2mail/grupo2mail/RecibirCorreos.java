package grupo2mail.grupo2mail;
import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;

/**
 * 
 * @author Javier Jim�nez Torres y Jose Garc�a Vegas
 * Clase de Recibir Correos 
 *
 */
public class RecibirCorreos {
	
	public static Message[] mensajes;
	private static String correo;
	private static String contrasenna;


	public RecibirCorreos(String correo, String contrasenna) {
		super();
		this.correo = correo;
		this.contrasenna = contrasenna;
	}

	public synchronized static void recibirCorreos() throws MessagingException {
		Properties prop = new Properties();

		// Deshabilitamos TLS
		prop.setProperty("mail.pop3.starttls.enable", "false");

		// Hay que usar SSL
		prop.setProperty("mail.pop3.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		prop.setProperty("mail.pop3.socketFactory.fallback", "false");

		// Puerto 995 para conectarse.
		prop.setProperty("mail.pop3.port", "995");
		prop.setProperty("mail.pop3.socketFactory.port", "995");
		
		prop.setProperty("mail.smtp.starttls.required", "true");
		prop.setProperty("mail.smtp.ssl.protocols", "TLSv1.2");


		Session sesion = Session.getInstance(prop);
		// sesion.setDebug(true); Esta linea es para mostrar mas informacion

		Store store = sesion.getStore("pop3");
		String mail = correo; // correo de la persona que rebibe los correo para leerlo
		String password = contrasenna;// y su contrase�a
		System.out.println("Hola: " + mail + " | " + password);
		store.connect("pop.gmail.com", mail, password);
		Folder folder = store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		mensajes = folder.getMessages();
		Collections.reverse(Arrays.asList(mensajes));
	}
	
	public void construirVentana() {
		try {
			TablaMailController.construirTabla(this);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // m�todo para contruir la tabla
	}
}
