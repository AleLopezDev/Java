package grupo2mail.grupo2mail;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JFileChooser;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;

public class RedactarCorreoControlador implements Initializable {

	@FXML
	Button btnEnviar;
	@FXML
	Button btnCancelar;
	@FXML
	Button btnAdjuntar;
	@FXML
	TextField cajaDestinatario;
	@FXML
	TextField cajaAsunto;
	@FXML
	TextField cajaAdjunto;
	@FXML
	TextArea cajaCuerpo;

	File fichero;

	String remitente;
	String clave;

	@FXML
	public void btnClick(ActionEvent e) throws IOException {
		System.out.println("He pulsado el boton enviar");
		Properties props = System.getProperties();
		props.put("mail.smtp.host", "smtp.gmail.com"); // El servidor SMTP de Google
		props.put("mail.smtp.user", remitente);
		props.put("mail.smtp.clave", clave); // La clave de la cuenta
		props.put("mail.smtp.auth", "true"); // Usar autenticación mediante usuario y clave
		props.put("mail.smtp.starttls.enable", "true"); // Para conectar de manera segura al servidor SMTP
		props.put("mail.smtp.port", "587"); // El puerto SMTP seguro de Google

		Session session = Session.getDefaultInstance(props);
		MimeMessage message = new MimeMessage(session);

		try {
			message.setFrom(new InternetAddress(remitente));
			message.addRecipients(Message.RecipientType.TO, cajaDestinatario.getText());
			BodyPart texto = new MimeBodyPart();
			texto.setText(cajaCuerpo.getText());

			BodyPart adjunto = new MimeBodyPart();
			MimeMultipart multiParte = new MimeMultipart();

			if (fichero!=null) {
				adjunto.setDataHandler(new DataHandler(new FileDataSource(fichero.getAbsolutePath())));
				adjunto.setFileName(String.valueOf(fichero.getCanonicalPath()));
				multiParte.addBodyPart(adjunto);
			}
			
			multiParte.addBodyPart(texto);

			message.setSubject(cajaAsunto.getText());
			message.setContent(multiParte);
			Transport transport = session.getTransport("smtp");
			transport.connect("smtp.gmail.com", remitente, clave);
			transport.sendMessage(message, message.getAllRecipients());
			transport.close();

		} catch (MessagingException me) {
			System.out.println("Ha fallado");
			me.printStackTrace();
		} catch (NullPointerException es) {
			System.out.println("Ha fallado");
			es.printStackTrace();
		}
		
		System.out.println("Ha terminado enviar");
	}

	@FXML
	public void adjuntar(ActionEvent e) {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Buscar Fichero");

		fichero = fileChooser.showOpenDialog((Stage) btnAdjuntar.getScene().getWindow());

		cajaAdjunto.setText(fichero.getAbsolutePath());
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

	public void recibirInfo(String correo, String contrasenna) {
		this.remitente = correo;
		this.clave = contrasenna;
	}
}
