package grupo2mail.grupo2mail;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.mail.MessagingException;

import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class TablaMailController implements Initializable {
	@FXML
	private TableView<Correo> tablaCorreo;
	@FXML
	private TableColumn destinatarioCL;
	@FXML
	private TableColumn asuntoCL;
	@FXML
	private TableColumn fechaCL;
	@FXML
	static ObservableList<Correo> correos;

	private RecibirCorreos rc;

	@FXML
	private Button redactar;
	@FXML
	private Button salir;
	@FXML
	private Button actualizar;
	@FXML
	private Button visualizar;

	static int control = 0;
	private int posicionCorreo;

	String correo;
	String contrasenna;
	String contenidoCorreo;

	URL url;
	ResourceBundle rb;

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		visualizar.setDisable(true);

		this.url = url;
		this.rb = rb;

		destinatarioCL.setCellValueFactory(new PropertyValueFactory<Correo, String>("destinatario"));
		asuntoCL.setCellValueFactory(new PropertyValueFactory<Correo, String>("asunto"));
		fechaCL.setCellValueFactory(new PropertyValueFactory<Correo, String>("fecha"));

		correos = FXCollections.observableArrayList();
		tablaCorreo.setItems(correos);

		try {
			construirTabla(rc);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		final ObservableList<Correo> tablaSel = tablaCorreo.getSelectionModel().getSelectedItems();
		tablaSel.addListener(selectorTablaCorreo);
	}

	private final ListChangeListener<Correo> selectorTablaCorreo = new ListChangeListener<Correo>() {
		@Override
		public void onChanged(ListChangeListener.Change<? extends Correo> c) {
			ponerCorreoSeleccionado();
		}

		private void ponerCorreoSeleccionado() {
			final Correo co = getTablaPersonasSeleccionada();
			posicionCorreo = correos.indexOf(co);

			try {
				contenidoCorreo = TipoMensaje.getTextFromMessage((rc.mensajes[posicionCorreo]));
				System.out.println(contenidoCorreo);
				visualizar.setDisable(false);
			} catch (MessagingException | IOException e) {
				e.printStackTrace();
			}
		}

		private Correo getTablaPersonasSeleccionada() {
			List<Correo> tabla = tablaCorreo.getSelectionModel().getSelectedItems();
			if (tabla.size() == 1) {
				final Correo seleccion = tabla.get(0);
				return seleccion;
			}
			return null;
		}
	};

	public void recibirParametros(RecibirCorreos rc, String correo, String contrasenna) {
		this.rc = rc;
		this.correo = correo;
		this.contrasenna = contrasenna;
	}

	public static void construirTabla(RecibirCorreos rc) throws MessagingException {
		if (control > 1) {
			System.out.println("Syso 1");
			correos.clear();
		} else {
			System.out.println("Syso 2");
			control++;
		}

		rc.recibirCorreos();
		for (int i = 0; i < rc.mensajes.length; i++) {
			Correo relleno = null;
			try {
				relleno = new Correo(rc.mensajes[i].getFrom()[0].toString(), rc.mensajes[i].getSubject().toString(),
						rc.mensajes[i].getSentDate().toString());
			} catch (MessagingException e) {
				e.printStackTrace();
			}
			correos.add(relleno);
		}
	}

	@FXML
	public void salida() {
		System.exit(0);
	}

	@FXML
	public void redactar() throws IOException {
		System.out.println("He pulsado en redactar");
		Stage stage = new Stage();
		FXMLLoader loader = new FXMLLoader();

		loader.setLocation(getClass().getResource("/grupo2/grupo2/VistaRedactar.fxml"));

		Pane ventana = (Pane) loader.load();
		Scene scene = new Scene(ventana);
		stage.setScene(scene);
		stage.show();

		RedactarCorreoControlador controller = (RedactarCorreoControlador) loader.getController();
		controller.recibirInfo(correo, contrasenna);
	}

	@FXML
	public void visualizar() throws IOException {
		System.out.println("He pulsado en visualizar");
		Stage stage = new Stage();
		FXMLLoader loader = new FXMLLoader();

		loader.setLocation(getClass().getResource("/grupo2/grupo2/VistaVerCorreo.fxml"));

		Pane ventana = (Pane) loader.load();
		Scene scene = new Scene(ventana);
		stage.setScene(scene);
		stage.show();

		VerCorreoController controller = (VerCorreoController) loader.getController();
		controller.recibirInfo(rc.mensajes, posicionCorreo, contenidoCorreo);
	}

	@FXML
	public void actualizar() {
		System.out.println("He pulsado en actualizar");
		try {
			visualizar.setDisable(true);
			rc.recibirCorreos();
			rc.construirVentana();
			System.out.println("Terminado");
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}
}
