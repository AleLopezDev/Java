package grupo2mail.grupo2mail;

import java.net.URL;
import java.util.ResourceBundle;

import javax.mail.Message;
import javax.mail.MessagingException;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class VerCorreoController implements Initializable {
	Message[] mensajes;
	int n;
	String contenido;

	@FXML
	private TextField remitente;
	@FXML
	private TextField asunto;
	@FXML
	private TextArea cuerpo;

	@FXML
	private Button cerrar;

	public void recibirInfo(Message[] mensajes, int n, String contenido) {
		this.mensajes = mensajes;
		this.n = n;
		
		try {
			remitente.setText(mensajes[n].getFrom()[0].toString());
			asunto.setText(mensajes[n].getSubject().toString());
			cuerpo.setText("Contenido: "+contenido.toString());
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}
}
