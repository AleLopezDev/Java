package grupo2mail.grupo2mail.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.ModeloConexion;


public class ConexionBD {
	private Statement miStatement;
	private Connection miConexion;
	private ResultSet result;
	private ModeloConexion miModelo;


	public ConexionBD() {
		miModelo = new ModeloConexion();

	}


	public void crearConexion() {
		try {
			// cargar el driver
			Class.forName(miModelo.getDriver());

			// establecemos la conexion con la BD
			miConexion = DriverManager.getConnection(miModelo.getUrl(), miModelo.getUsuario(),
					miModelo.getContrasenia());

			// establecer conexion BD
			miStatement = miConexion.createStatement();
		
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}


	public boolean existeUsusuario(String sql) {

		try {
			result = miStatement.executeQuery(sql);
			if (result.next()) {
				System.out.println("El usuario existe");
				return true;
			} else {
				System.out.println("El usuario no existe");
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * get
	 * @return
	 */
	public ResultSet getResult() {
		return result;
	}

	/**
	 * set
	 * @param result
	 */
	public void setResult(ResultSet result) {
		this.result = result;
	}

}