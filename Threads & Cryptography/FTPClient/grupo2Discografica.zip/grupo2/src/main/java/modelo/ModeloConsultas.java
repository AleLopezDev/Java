package modelo;

public class ModeloConsultas {

	private String existeUsuario;

	public ModeloConsultas() {

	}

	public String getExisteUsuario(String email, String passwd) {
		existeUsuario = "SELECT nombre_usuario, contrasenna_usuario from correo where nombre_usuario like '" + email
				+ "' and contrasenna_usuario like '" + passwd + "'";
		return existeUsuario;
	}

	public void setExisteUsuario(String existeUsuario) {
		this.existeUsuario = existeUsuario;
	}

}
