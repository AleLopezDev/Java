
module Grupo2.grupo2 {
    requires javafx.controls;
    requires javafx.fxml;
	requires java.sql;
	requires java.desktop;
	requires javafx.graphics;
	requires org.apache.commons.net;
	requires ftpserver.core;
	requires de.jensd.fx.glyphs.fontawesome;
	requires java.mail;
	requires activation;
	requires org.jsoup;


    opens Grupo2.grupo2 to javafx.fxml;
    exports Grupo2.grupo2;
    
    opens Grupo2.grupo2.controladores to javafx.fxml;
    exports Grupo2.grupo2.controladores;
    
    opens grupo2mail.grupo2mail to javafx.fxml;
    exports grupo2mail.grupo2mail;
    
    //open controladores to javafx.fxml;
    
}

